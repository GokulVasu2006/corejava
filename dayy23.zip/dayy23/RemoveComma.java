package dayy23;
import java.util.*;
public class RemoveComma {
	public static void main(String[] args) {
		String a="hello,gokul,vasu";
		String[] b=a.split(",");
		for(int i=0;i<b.length;i++) {
			System.out.println(b[i]);
		}
	}

}
