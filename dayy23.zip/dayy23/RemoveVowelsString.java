package dayy23;

public class RemoveVowelsString {
	public static void main(String[] args) {
		String a="abcdefghi";
		System.out.println(a);
		System.out.println(a.replaceAll("[aeiou]",""));
	}

}
