package day2;

public class DataType {
	public static void main(String[] args) {
		byte a=-128;
		System.out.println("the byte is "+a);
		short b=129;
		System.out.println("the short is "+b);
		int c=1200;
		System.out.println("the int is "+c);
		long d=9213456789l;
		System.out.println("the long is "+d);
		float e=123.454f;
		System.out.println("the float is "+e);
		double f=2345.567d;
		System.out.println("the double is "+f);
		boolean g =true;
		System.out.println("this is "+g);
		char h='G';
		System.out.println("the char is "+h);
		
	}

}
