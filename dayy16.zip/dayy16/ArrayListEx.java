package dayy16;
import java.util.ArrayList;
public class ArrayListEx {
	public static void main(String[] args) {
		ArrayList<Integer> a=new ArrayList<Integer>();
		a.add(1);
		a.add(2);
		a.add(3);
		a.add(4);
		ArrayList<Integer> b=new ArrayList<Integer>();
		b.add(5);
		b.add(6);
		b.add(7);
		b.add(8);
		a.addAll(b);
		System.out.println(a);//adding 2 arrays ie a and b
		System.out.println(a.get(5));//getting 5th index value ie op will be 6
		a.set(0, 11);
		System.out.println(a);//set is used to change one value to another
		a.remove(0);
		System.out.println(a);//it will remove the integer 
		a.removeAll(b);
		System.out.println(a);//it will remove all the necessary ones.
		System.out.println(a.size());//it will tell the size of the array
		System.out.println(a.isEmpty());//it will tell whether it has any content or no return boolean value
		System.out.println(a.contains(b));//it will tell the given object is present or not 
		System.out.println(b.containsAll(a));
		System.out.println(a.indexOf(3));
		a.forEach(s -> System.out.println(s));
		Integer[] arr=a.toArray(new Integer[a.size()]);
		for(int i=0;i<=a.size()-1;i++) {
			System.out.print(arr[i]);
		}
		

	}

}
