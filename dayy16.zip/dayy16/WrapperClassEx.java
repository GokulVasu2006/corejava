package dayy16;

public class WrapperClassEx {
	public static void main(String[] args) {
	    int primitiveInt = 10;
	    Integer wrapperInt = primitiveInt; // Autoboxing: int to Integer
	    System.out.println(wrapperInt);
	    //unboxing Integer to int
	    Integer wrapperClass=15;
	    int primitive=wrapperClass;
	    System.out.println(primitive);
	}

}
