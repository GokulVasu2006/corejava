package dayy17;

public class Employee {
    private int id;
    private String name;
    private long phno;
    private double salary;

    // Getters and setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public long getPhno() {
        return phno;
    }
    public void setPhno(long phno) {
        this.phno = phno;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }

    // Constructors
    public Employee() {}
    public Employee(int id, String name, long phno, double salary) {
        this.id = id;
        this.name = name;
        this.phno = phno;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + ", phno=" + phno + ", salary=" + salary + "]";
    }
}
