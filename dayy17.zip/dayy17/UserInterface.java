package dayy17;

import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) {
        ArrayList<Employee> empList = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        boolean isTrue = true;

        while (isTrue) {
            System.out.println("\n--- MENU ---");
            System.out.println("Press 1 for creating");
            System.out.println("Press 2 for viewing");
            System.out.println("Press 3 for modify");
            System.out.println("Press 0 for quit");
            int key = sc.nextInt();

            if (key == 1) {
                System.out.print("Enter the id: ");
                int id = sc.nextInt();
                sc.nextLine(); // clear buffer

                System.out.print("Enter the name: ");
                String name = sc.nextLine();

                System.out.print("Enter the phone no: ");
                long phno = sc.nextLong();

                System.out.print("Enter the salary: ");
                double salary = sc.nextDouble();

                // Create employee with values
                Employee e = new Employee(id, name, phno, salary);
                empList.add(e);

                System.out.println("✅ Employee added successfully!");

            } else if (key == 2) {
                if (empList.isEmpty()) {
                    System.out.println("No employees found.");
                } else {
                    System.out.println("\n--- Employee List ---");
                    for (Employee e : empList) {
                        System.out.println(e);
                    }
                }

            } else if (key == 3) {
                System.out.print("Enter employee ID to modify: ");
                int searchId = sc.nextInt();
                Employee found = null;

                for (Employee e : empList) {
                    if (e.getId() == searchId) {
                        found = e;
                        break;
                    }
                }

                if (found != null) {
                    boolean modifyLoop = true;
                    while (modifyLoop) {
                        System.out.println("\n--- Modify Menu ---");
                        System.out.println("1. Modify ID");
                        System.out.println("2. Modify Name");
                        System.out.println("3. Modify Salary");
                        System.out.println("0. Exit Modify");
                        int choice = sc.nextInt();

                        switch (choice) {
                            case 1:
                                System.out.print("Enter new ID: ");
                                found.setId(sc.nextInt());
                                break;
                            case 2:
                                System.out.print("Enter new Name: ");
                                sc.nextLine(); // clear buffer
                                found.setName(sc.nextLine());
                                break;
                            case 3:
                                System.out.print("Enter new Salary: ");
                                found.setSalary(sc.nextDouble());
                                break;
                            case 0:
                                modifyLoop = false;
                                break;
                            default:
                                System.out.println("Invalid choice.");
                        }
                    }
                } else {
                    System.out.println("Employee not found.");
                }

            } else if (key == 0) {
                System.out.println("Exiting...");
                isTrue = false;
            } else {
                System.out.println("Enter a valid option.");
            }
        }

        sc.close();
    }
}
