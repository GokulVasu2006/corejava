package dayy30;
import java.sql.*;
public class Connect {
	public static void main(String[] args) throws SQLException {
		String url="jdbc:mysql://localhost:3306/nirmaan";
		String username="root";
		String pwd="123456789";
		Connection con=DriverManager.getConnection(url,username,pwd);
		Statement s=con.createStatement();
		ResultSet rs=s.executeQuery("select * from stu");
		System.out.println("Id  "+"name  "+"age  ");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3));
		}
		PreparedStatement ps=con.prepareStatement("insert into stu values(?,?,?)");
		ps.setInt(1, 3);
		ps.setString(2, "rocky");
		ps.setInt(3, 18);
		ps.executeUpdate();
				
	}

}
