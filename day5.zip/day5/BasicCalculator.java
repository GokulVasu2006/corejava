package day5;

import java.util.Scanner;

public class BasicCalculator {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your choice");
		System.out.println("1:Add 2:Sub 3:Mul 4:Div 5:Mod");
		int key=sc.nextInt();
		switch(key) {
		case 1:
			System.out.println("add");
			System.out.println("enter 1st number");
			int a=sc.nextInt();
			System.out.println("enter 2nd number");
			int b=sc.nextInt();
			System.out.println(a+b);
			break;
		case 2:
			System.out.println("sub");
			System.out.println("enter 1st number");
			int c=sc.nextInt();
			System.out.println("enter 2nd number");
			int d=sc.nextInt();
			System.out.println(c-d);
			break;
		case 3:
			System.out.println("mul");
			System.out.println("enter 1st number");
			int e=sc.nextInt();
			System.out.println("enter 2nd number");
			int f=sc.nextInt();
			System.out.println(e*f);
			break;
		case 4:
			System.out.println("div");
			System.out.println("enter 1st number");
			int g=sc.nextInt();
			System.out.println("enter 2nd number");
			int h=sc.nextInt();
			System.out.println(g/h);
			break;
		case 5:
			System.out.println("mod");
			System.out.println("enter 1st number");
			int i=sc.nextInt();
			System.out.println("enter 2nd number");
			int j=sc.nextInt();
			System.out.println(i%j);
			break;
		default:
			System.out.println("enter correct choice");
		}
	}

}
