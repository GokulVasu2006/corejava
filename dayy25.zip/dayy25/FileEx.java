package dayy25;
import java.io.*;
import java.util.Scanner;
public class FileEx {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		boolean isTrue=true;
		while(isTrue) {
			System.out.println("enter your choice");
			System.out.println("1 for create file");
			System.out.println("2 for write file");
			System.out.println("3 for read file");
			System.out.println("4 for append file");
			int key=sc.nextInt();
			switch(key) {
			case 1:
				System.out.println("Enter file name");
				String s=sc.next();
				File f=new File(s);
				if(f.createNewFile()) {
					System.out.println("file created");
				}else {
					System.out.println("file Exists");
				}
				break;
			case 2:
				System.out.println("enter file name");
				String s1=sc.next();
				FileWriter fr=new FileWriter(s1);
				System.out.println("enter the text");
				String s2=sc.nextLine();
				fr.write(s2);
				fr.close();
				System.out.println("text written");
				break;
			case 3:
				System.out.println("enter file name");
				String s3=sc.next();
				BufferedReader bf=new BufferedReader(new FileReader(s3));
				String text;
				while((text=bf.readLine())!=null) {
					System.out.println(text);
				}break;
			case 4:
				System.out.println("enter the file name");
				String s4=sc.next();
				FileWriter fr1=new FileWriter(s4,true);
				System.out.println("enter the text");
				String s5=sc.nextLine();
				fr1.write(s4);
				fr1.close();
				break;
			default:
				System.out.println("enter correct choice");
				
			}
		}
		
		
	}

}
